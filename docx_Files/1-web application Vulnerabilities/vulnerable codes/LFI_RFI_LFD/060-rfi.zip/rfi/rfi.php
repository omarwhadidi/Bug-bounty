<?php

	echo "File included: ".$_REQUEST["file"]."<br>";
	echo "<br><br>";
	include $_REQUEST["file"];
	echo "<br><br>";

?>


